from django.urls import path
from . import views
urlpatterns = [
    path('',views.home, name='index'),
    path('x-axis',views.x_axis, name='x-axis'),
    path('y-axis',views.y_axis, name='y-axis'),
    path('diagonal',views.diagonal, name='diagonal'),
]