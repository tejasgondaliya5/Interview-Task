from django.urls import path
from . import views
urlpatterns = [
    path('',views.home, name='index'),
    path('x-axis',views.x_axis, name='x-axis'),
    path('y-axis',views.y_axis, name='y-axis'),
    path('diagonal_45',views.diagonal_45, name='diagonal'),
    path('diagonal_135',views.diagonal_135, name='diagonal_135'),
    path('All',views.All, name='all'),
    path('None',views.none, name='none'),
]