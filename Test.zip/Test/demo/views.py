from django.shortcuts import render
import openpyxl

# Create your views here.

def home(request):
    return render(request, 'index.html')

def x_axis(request):

    wb = openpyxl.load_workbook("demo\\Task.xlsx")
    sh1 = wb['Sheet1']
    row = sh1.max_row
    im=[]
    j=1
    for i in range(1,row+1):
        data = sh1.cell(i,3).value
        if data==1:
            img = sh1.cell(i,2).value
            if j<41:
                im.append(img)
            j+=1
    return render(request,'x-axis.html',{'data':im})


def y_axis(request):
    wb = openpyxl.load_workbook("demo\\Task.xlsx")
    sh1 = wb['Sheet1']
    row = sh1.max_row
    im=[]
    j=0
    for i in range(1,row+1):
        data = sh1.cell(i,4).value
        if data==1:
            img = sh1.cell(i,2).value
            if j<41:
                im.append(img)
            j+=1
            
    return render(request,'y-axis.html',{'data':im})

def diagonal_45(request):
    wb = openpyxl.load_workbook("demo\\Task.xlsx")
    sh1 = wb['Sheet1']
    row = sh1.max_row
    im=[]
    j=0
    for i in range(1,row+1):
        data = sh1.cell(i,5).value
        if data==1:
            img = sh1.cell(i,2).value
            if j<41:
                im.append(img)
            j+=1
    return render(request,'diagonal.html',{'data':im})

def diagonal_135(request):
    wb = openpyxl.load_workbook("demo\\Task.xlsx")
    sh1 = wb['Sheet1']
    row = sh1.max_row
    im=[]
    j=0
    for i in range(1,row+1):
        data = sh1.cell(i,6).value
        if data==1:
            img = sh1.cell(i,2).value
            if j<41:
                im.append(img)
            j+=1
    return render(request,'diagonal_135.html',{'data':im})


def All(request):
    wb = openpyxl.load_workbook("demo\\Task.xlsx")
    sh1 = wb['Sheet1']
    row = sh1.max_row
    im=[]
    j=0
    for i in range(1,row+1):
        data = sh1.cell(i,7).value
        if data==1:
            img = sh1.cell(i,2).value
            if j<41:
                im.append(img)
            j+=1
    return render(request,'All.html',{'data':im})

def none(request):
    wb = openpyxl.load_workbook("demo\\Task.xlsx")
    sh1 = wb['Sheet1']
    row = sh1.max_row
    im=[]
    j=0
    for i in range(1,row+1):
        data = sh1.cell(i,8).value
        if data==1:
            img = sh1.cell(i,2).value
            if j<41:
                im.append(img)
            j+=1
    return render(request,'none.html',{'data':im})
