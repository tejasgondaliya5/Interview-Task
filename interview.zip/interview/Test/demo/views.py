from django.shortcuts import render
import openpyxl

# Create your views here.

def home(request):
    return render(request, 'index.html')

def x_axis(request):
    # mam please your .xlsx file according set the path.
    wb = openpyxl.load_workbook("D:\\pycharm\\interview\\Task.xlsx")
    sh1 = wb['Sheet1']
    row = sh1.max_row
    im=[]
    j=1
    for i in range(1,row+1):
        data = sh1.cell(i,3).value
        if data==1:
            img = sh1.cell(i,2).value
            # mem i am not understend for this criteria so i create only first 40 img is show.
            if j<41:
                im.append(img)
            j+=1
    return render(request,'x-axis.html',{'data':im})


def y_axis(request):
    wb = openpyxl.load_workbook("D:\\pycharm\\interview\\Task.xlsx")
    sh1 = wb['Sheet1']
    row = sh1.max_row
    im=[]
    j=0
    for i in range(1,row+1):
        data = sh1.cell(i,4).value
        if data==1:
            img = sh1.cell(i,2).value
            if j<41:
                im.append(img)
            j+=1
            
    return render(request,'y-axis.html',{'data':im})

def diagonal(request):
    wb = openpyxl.load_workbook("D:\\pycharm\\interview\\Task.xlsx")
    sh1 = wb['Sheet1']
    row = sh1.max_row
    im=[]
    j=0
    for i in range(1,row+1):
        data = sh1.cell(i,5).value
        if data==1:
            img = sh1.cell(i,2).value
            if j<41:
                im.append(img)
            j+=1
    return render(request,'diagonal.html',{'data':im})
